# Mixed Medaka Ricefish (MMR) dataset

Bounding-box dataset of two Indonesian ricefishes, accompanying the article
*Medaka-EL: A Robust Ensemble Learning Framework for the Detection of Indonesian Ricefish under Data Scarcity*.

DOI: https://doi.org/10.5281/zenodo.23837341
Licence: CC BY 4.0

## Classes

| ID | Species |
|----|---------|
| 0 | *Oryzias celebensis* (Celebes medaka) |
| 1 | *Oryzias javanicus* (Javanese medaka) |

## Contents

```
images/train, images/valid, images/test   ex-situ images (768 of 1,139)
labels/train, labels/valid, labels/test   YOLO labels for all 1,139 images
data.yaml                                  YOLO dataset configuration
splits.csv                                 partition, source and box counts of every image
web_image_sources.csv                      the 371 web images that are not redistributed
```

## Dataset summary

| | Images | Boxes |
|---|---|---|
| *O. celebensis* | 590 | 645 |
| *O. javanicus* | 549 | 599 |
| Total | 1,139 | 1,244 |

| Partition | Images | Role in the paper |
|---|---|---|
| train | 820 | training pool |
| valid | 206 | training pool |
| test | 113 | hold-out set (used only for final evaluation) |

The training pool (train + valid, 1,026 images) was further divided into five
cross-validation folds for the Medaka-EL fold models.

Sources: 768 ex-situ images taken in an aquarium (17 August 2023) and 371 web images
(downloaded images, screenshots and frames from two YouTube videos).

## Format and preprocessing

Labels are in YOLO format, one `.txt` file per image, one line per fish:
`class x_center y_center width height`, normalised to [0, 1].

Images were auto-oriented and resized to 640 x 640 pixels (stretched) in Roboflow;
no augmentation was applied. Original-resolution images are not included.

## Web images

Web images whose licences do not permit redistribution are not included. Their labels
are provided, and `web_image_sources.csv` lists their filename, partition, source type
and the SHA-256 hash of the 640 x 640 file used in the experiments.

## Usage

```python
from ultralytics import YOLO
model = YOLO("yolov8n.pt")
model.train(data="data.yaml", imgsz=640, epochs=50)
```

Training on this archive uses the ex-situ images only, because the web images are not included.

## Citation

Please cite the article and this dataset (DOI above).
